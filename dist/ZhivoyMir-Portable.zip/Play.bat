@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Проверка обновлений сборки "Живой мир"...
java -jar packwiz-installer-bootstrap.jar https://gogobutters.github.io/mc/pack.toml
if errorlevel 1 (
  echo.
  echo Не удалось обновить. Проверьте, что установлена Java 21: https://adoptium.net
  pause
  exit /b 1
)
echo.
echo Моды обновлены. Откройте лаунчер и запустите игру.
pause
